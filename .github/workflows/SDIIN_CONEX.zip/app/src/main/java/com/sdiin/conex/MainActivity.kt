package com.sdiin.conex

class MainActivity {}
